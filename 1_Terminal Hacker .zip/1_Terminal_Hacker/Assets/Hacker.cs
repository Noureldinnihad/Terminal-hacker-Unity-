﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hacker : MonoBehaviour
{
    // Start is called before the first frame update
enum Screen{mainMenu,password,win}
 Screen currentScreen=Screen.mainMenu;
    void Start()
    {
       showMainMenu("Hello hacker :) \n");

    }
    void showMainMenu(  string greeting){
        currentScreen=Screen.mainMenu;
       Terminal.WriteLine(greeting);
    
     Terminal.WriteLine(" What would you like to hack:");
     Terminal.WriteLine(" Press 1 to start hacking in to a Wifi network (easy)");
          Terminal.WriteLine(" Press 2 to start hacking in to a government network (Normal)");
     Terminal.WriteLine(" Press 3 to start hacking in to a Nasa's network (Hard)");

    }
    private void Update() {
       
    }
int lvl;

    void OnUserInput(string input)
    {
        runMainMenu(input);

    }

     void runMainMenu(string input)
    {
        if (input == "1")
        {
            lvl = 1;
            startGame();
            currentScreen = Screen.password;
            Terminal.WriteLine("Enter the Paswword :");
        }
        else if (input == "2")
        {
            lvl = 2;
            startGame();
                        Terminal.WriteLine("Enter the Paswword :");

        }
        else if (input == "3")
        {
            lvl = 3;
            startGame();
                        Terminal.WriteLine("Enter the Paswword :");


        }
        else if (input == "4")
        {
            Terminal.WriteLine("Welcome proHacker 69");

        }
        else if (input == "menu")
        {
            showMainMenu("Hello hacker :) \n");

        }

        else
        {
            Terminal.WriteLine("Smd");

        }
    }

    void OnDisable() {
        print("smd");
                

    }
    void startGame(){

Terminal.WriteLine("you chose "+lvl);
           currentScreen=Screen.password;

    }
   
}
